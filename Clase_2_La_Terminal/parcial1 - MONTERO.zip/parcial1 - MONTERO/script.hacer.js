

/*

function aleatorio(minimo,maximo){
  return Math.floor(Math.random() * ((maximo+1)-minimo)+minimo);
}
//console.log(aleatorio(1, 100));

var colores=["red", "green", "blue", "pink", "yellow", "brown", "hotpink", "orange", "gold", "khaki", "fuchsia", "greenyellow", "lime", "olive", "teal", "aquamarine", "royalblue", "sandybrown"];



function verificaNumero(numero){

	var num = numero;
	


}

verificaNumero();




function fabricaCajas(){
	var miCaja = document.createElement("div");
	miCaja.style.height = "100px";
	//de esta forma le puedo aplicar estilo css inline al elemento que acabo de crear
	
}


*/