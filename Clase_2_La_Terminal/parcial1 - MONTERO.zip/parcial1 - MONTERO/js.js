
function verificaNumero(numero){

var num = numero;

var colores=["red", "green", "blue", "pink", "yellow", "brown", "hotpink", "orange", "gold", "khaki", "fuchsia", "greenyellow", "lime", "olive", "teal", "aquamarine", "royalblue", "sandybrown"];

if(!isNaN(num)){
	//console.log("El usuario ingreso " + num + " cajas");
	for (var i = 1; i <= num; i++) {
		document.write("<div class='divCaja'>" + num + "</div>");
	}
	

}else{
	prompt("No ingreso un número. Cuantas cajas desea?");
	verificaNumero(prompt("Cuantas cajas desea?"));
}
}

verificaNumero(prompt("Cuantas cajas desea?"));


/*
	function fabricaCajas(){
		var miCaja = document.createElement("div");
		miCaja.style.padding = "50px";
		miCaja.style.margin = "10px";
		miCaja.style.height = "100px";
		miCaja.style.background-color = colores;
	}

	fabricaCajas();

*/